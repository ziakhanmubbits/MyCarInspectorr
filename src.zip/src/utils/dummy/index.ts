export const dummyUsers = [
  {email: 'admin@test.com', password: 'admin123'},
  {email: 'user@test.com', password: 'user123'},
  {email: 'test@test.com', password: 'test123'},
];

export const inspectionModes = [
  {id: 'line', label: 'Draw Line', icon: ''},
  {id: 'circle', label: 'Add Circle', icon: ''},
  {id: 'none', label: 'View Only', icon: ''},
];